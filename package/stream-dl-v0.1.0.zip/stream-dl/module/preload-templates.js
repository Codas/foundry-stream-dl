export const preloadTemplates = async function () {
    const templatePaths = ["./modules/stream-dl/templates/stream-download.html" /* STREAM_DL_PATH */];
    return loadTemplates(templatePaths);
};
