import { STREAM_DL } from "./config.js";
import { sanitize } from "./sanitize-filename.js";
export function _onRenderPlaylistDirectory(app, html, data) {
    _addStreamConfig(html);
}
function _addStreamConfig(html) {
    const playlistFooter = html.find('.directory-footer');
    const streamButtonHtml = `<button type="button" class="stream-dl-button">
<span class="fa-stack fa-xs">
  <i class="fas fa-cloud fa-stack-2x"></i>
  <i class="fas fa-music fa-stack-1x fa-inverse" style="left: -1px; top: 1px;"></i>
</span>
  <span>Stream DL</span>
</button>`;
    const streamButtonWrappedHtml = `<div class="flexrow stream-dl-flex-full">${streamButtonHtml}</div>`;
    playlistFooter.append(streamButtonWrappedHtml);
    const streamButton = html.find('.stream-dl-button');
    streamButton.on('click', (evt) => {
        new StreamDlForm({}).render(true);
    });
}
class StreamDlForm extends FormApplication {
    constructor(data, options) {
        super(Object.assign(Object.assign({}, data), { saveTrack: true }), Object.assign(Object.assign({}, options), { closeOnSubmit: false }));
        this.data = data;
        this.config = {
            authKey: game.settings.get(STREAM_DL.MODULE_NAME, "AUTH_KEY" /* AUTH_KEY */),
            backendUrl: game.settings.get(STREAM_DL.MODULE_NAME, "BACKEND_URL" /* BACKEND_URL */),
            dataPath: game.settings.get(STREAM_DL.MODULE_NAME, "DATA_PATH" /* DATA_PATH */),
        };
    }
    /**
     * Default Options for this FormApplication
     */
    static get defaultOptions() {
        return Object.assign(Object.assign({}, super.defaultOptions), { id: 'stream-dl-form', title: 'Stream Download', template: "./modules/stream-dl/templates/stream-download.html" /* STREAM_DL_PATH */, classes: ['sheet'], width: 500 });
    }
    get isEditable() {
        return !this.data.isSaving;
    }
    _updateObject(event, formData) {
        var _a;
        if ((formData.saveTrack && !formData.playlist) || !formData.title || !formData.url) {
            return;
        }
        const url = /^[a-zA-Z0-9_-]+$/.test(formData.url)
            ? `https://www.youtube.com/watch?v=${formData.url}`
            : formData.url;
        this.data = Object.assign(Object.assign(Object.assign({}, ((_a = this.data) !== null && _a !== void 0 ? _a : null)), formData), { url: url, isSaving: true });
        this.render();
        this.downloadStream(formData);
    }
    /**
     * Provide data to the template
     */
    getData() {
        return Object.assign(Object.assign({}, this.data), { playlists: game.playlists.entities });
    }
    async downloadStream(formData) {
        try {
            const sanitizedTitle = sanitize(formData.title, '_');
            const filename = !formData.filename || formData.filename.endsWith('/')
                ? `${formData.filename}${sanitizedTitle}`
                : formData.filename;
            const res = await $.ajax({
                method: 'POST',
                url: `${this.config.backendUrl}/download`,
                contentType: 'application/json',
                headers: {
                    'x-api-key': this.config.authKey,
                },
                dataType: 'json',
                data: JSON.stringify({
                    title: filename,
                    url: formData.url,
                }),
            }).promise();
            // @ts-ignore
            ui.notifications.info(`Track successfully created as "${formData.title}".`);
            if (!formData.saveTrack) {
                await this.close();
                return;
            }
            const playlist = game.playlists.get(formData.playlist);
            const path = `${this.config.dataPath}/${res.filename}`;
            await playlist.createEmbeddedEntity('PlaylistSound', { name: formData.title, path });
            await this.close();
        }
        catch (e) {
            // @ts-ignore
            ui.notifications.error(`Could not create track. See console for details.`);
            console.error(e);
            this.data.isSaving = false;
            this.render();
        }
    }
    activateListeners(html) {
        super.activateListeners(html);
        const saveTrackCheckbox = html.find('input[name="saveTrack"]');
        saveTrackCheckbox.on('change', (event) => {
            this.data.saveTrack = event.target.checked;
            if (this.data.saveTrack) {
                html.find('select[name="playlist"]').removeAttr('disabled');
            }
            else {
                html.find('select[name="playlist"]').attr('disabled', 'disabled');
            }
        });
    }
}
