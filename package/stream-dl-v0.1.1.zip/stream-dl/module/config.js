export var STREAM_DL;
(function (STREAM_DL) {
    STREAM_DL.MODULE_NAME = 'stream-dl';
})(STREAM_DL || (STREAM_DL = {}));
